let handler = async (m, {conn}) => {
if (!m.quoted) throw 'reply saluran channel nya lah'
try {
let id = (await m.getQuotedObj()).msg.contextInfo.forwardedNewsletterMessageInfo
await m.reply(`Name: ${id.newsletterName}\nId: ${id.newsletterJid}`)
} catch (e) {
throw 'Harus chat dari channel bang'
}
}
handler.help = handler.command = ['idc']
handler.tags = ['owner']
handler.rowner = true
handler.daftar = true
export default handler